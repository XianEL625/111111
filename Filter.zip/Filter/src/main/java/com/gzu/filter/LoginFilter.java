package com.gzu.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * LoginFilter是一个Servlet过滤器，用于检查用户的身份验证。
 * 它允许对登录页面、注册页面以及公共资源的访问。
 */
@WebFilter(urlPatterns = "/*")
public class LoginFilter implements Filter {
    // 不需要登录就能访问的路径排除列表
    private List<String> excludedPaths = Arrays.asList("/login", "/register", "/public");

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String requestURI = httpRequest.getRequestURI();

        // 检查请求路径是否在排除列表中
        if (isExcludedPath(requestURI)) {
            chain.doFilter(request, response);
            return;
        }

        // 检查用户是否已登录
        HttpSession session = httpRequest.getSession(false);
        if (session!= null && session.getAttribute("user")!= null) {
            System.out.println("User is logged in. Allowing access.");
            chain.doFilter(request, response);
        } else {
            System.out.println("User is not logged in. Redirecting to login page.");
            httpResponse.sendRedirect("/Filter_war_exploded/login.html");
        }
    }

    private boolean isExcludedPath(String uri) {
        return excludedPaths.stream().anyMatch(uri::contains);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Filter init method
    }

    @Override
    public void destroy() {
        // Filter destroy method
    }
}