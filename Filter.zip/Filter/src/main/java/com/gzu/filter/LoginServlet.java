package com.gzu.filter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    // 预设用户账号和密码
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 检查用户名和密码是否正确
        if (USERNAME.equals(username) && PASSWORD.equals(password)) {
            // 登录成功，将用户信息存入 session
            HttpSession session = request.getSession();
            session.setAttribute("user", username);
            System.out.println("Login successful. Redirecting to welcome page.");
            response.sendRedirect("/Filter_war_exploded/welcome.html");
        } else {
            // 登录失败，返回登录页面
            System.out.println("Login failed. Redirecting to login page with error.");
            response.sendRedirect("/Filter_war_exploded/login.html?error=1");
        }
    }
}