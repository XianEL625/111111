package com.gzu;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CRUD {
private static final String url= "jdbc:mysql://localhost:3306/jdbc_test?serverTimezone=GMT&characterEncoding=UTF-8";
private static final String user="root";
private static final String password="mimashi625";
public  static  void main(String[] args) throws RuntimeException, SQLException {
    Connection conn = null;
    try {
        conn = DriverManager.getConnection(url, user, password);
        conn.setAutoCommit(false);

        QueryRunner runner = new QueryRunner();

        //增
        String sql1 = "insert into teacher(id,name,course,birthday) values (?,?,?,?)";
        int insertResult = runner.update(conn, sql1, 1,"伍六七", "洗剪吹", "2003-06-25");
        System.out.println("增" + insertResult + "row(s)");

        //查询
        String sql2 = "select * from teacher where id=?";
        Teacher teacher = runner.query(conn, sql2, new BeanHandler<>(Teacher.class), 1);
        System.out.println("查" + teacher);

        //改
        String sql3 = "update teacher set name=? where id=?";
        int updateResult = runner.update(conn, sql3, "鸡大保", 1);
        System.out.println("改" + updateResult + "row(s)");

        //删
        String sql4 = "delete from teacher where id=?";
        int deletResult = runner.update(conn, sql4, 1);
        System.out.println("删" + deletResult + "row(s)");

        //提交
        DbUtils.commitAndClose(conn);
    } catch (SQLException sqlException) {
        sqlException.printStackTrace();
        DbUtils.rollbackAndCloseQuietly(conn); // Rollback transaction and close connection quietly
    } catch (Exception e) {
        e.printStackTrace();
        DbUtils.closeQuietly(conn); // Close connection quietly
    }
}}