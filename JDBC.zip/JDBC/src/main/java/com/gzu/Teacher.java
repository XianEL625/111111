package com.gzu;

import jdk.jfr.DataAmount;

@DataAmount
public class Teacher {
private int id;
private String name;
private  String course;
private  String birthday;
}
