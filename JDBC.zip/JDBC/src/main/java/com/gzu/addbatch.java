package com.gzu;

import java.sql.*;

public class addbatch {
    public static void main(String[] args) {
        String url= "jdbc:mysql://localhost:3306/jdbc_test?serverTimezone=GMT&characterEncoding=UTF-8";
        String user="root";
        String password="mimashi625";
        String sql="insert into teacher(id,name,course,birthday) values (?,?,?,?)";
        try(Connection conn = DriverManager.getConnection(url,user,password);) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql);){
            for(int i=1;i<=500;i++){
            ps.setInt(1,i);
            ps.setString(2,"name"+i);
            ps.setString(3,i%2==0?"文科":"理科");
            ps.setDate(4, Date.valueOf("2002-06-25"));
            //添加到批处理

                ps.addBatch();
                if(i%100==0){//每100条记录执行一次批处理
                    ps.executeBatch();
                    ps.clearBatch();
                }
            }
            ps.executeBatch();
            conn.commit();
            System.out.println("完成批量插入数据");
        } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }}}
