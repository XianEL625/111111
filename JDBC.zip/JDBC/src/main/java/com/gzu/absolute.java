package com.gzu;
import java.sql.*;

public class absolute {
    public static void main(String[] args) {
        String url= "jdbc:mysql://localhost:3306/jdbc_test?serverTimezone=GMT&characterEncoding=UTF-8";
        String user="root";
        String password="mimashi625";
        String sql= "SELECT * FROM teacher";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ) {
            try (ResultSet rs = ps.executeQuery()) {
                rs.absolute(-2);
                System.out.println(rs.getInt("id") + " " + rs.getString("name"));
            }catch (SQLException e) {
                e.printStackTrace();
            }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    }}
