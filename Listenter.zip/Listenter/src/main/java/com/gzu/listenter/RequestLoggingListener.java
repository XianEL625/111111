package com.gzu.listenter;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.http.HttpServletRequest;

import java.util.logging.Level;
import java.util.logging.Logger;

public class RequestLoggingListener implements ServletRequestListener {

    private static final Logger logger = Logger.getLogger(RequestLoggingListener.class.getName());

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        long startTime = System.currentTimeMillis();
        request.setAttribute("startTime", startTime);
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        Long startTime = (Long) request.getAttribute("startTime");
        long endTime = System.currentTimeMillis();

        String clientIP = request.getRemoteAddr();
        String requestMethod = request.getMethod();
        String requestURI = request.getRequestURI();
        String queryString = request.getQueryString();
        String userAgent = request.getHeader("User-Agent");

        long processingTime = endTime - startTime;

        // Log the request details
        String logMessage = String.format(
                "Time: %s, IP: %s, Method: %s, URI: %s, Query: %s, User-Agent: %s, Processing Time: %d ms",
                new java.util.Date(), clientIP, requestMethod, requestURI, queryString, userAgent, processingTime);
        logger.log(Level.INFO, logMessage);
    }
}
